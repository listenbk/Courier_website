-- One-time repair script for the default admin account.
-- Import this file in phpMyAdmin if admin / password is not accepted.
-- It only resets the password for the username "admin".

USE `mount_mary_couriers`;

INSERT INTO `admins` (`username`, `password_hash`)
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.')
ON DUPLICATE KEY UPDATE `password_hash` = VALUES(`password_hash`);
