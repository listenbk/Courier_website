-- Mount Mary Couriers database
-- Import this file in phpMyAdmin, then update database credentials in includes/config.php.

CREATE DATABASE IF NOT EXISTS `mount_mary_couriers`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `mount_mary_couriers`;

CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(80) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_username_unique` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default login: admin / password. Change it after deployment.
INSERT INTO `admins` (`username`, `password_hash`)
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.')
ON DUPLICATE KEY UPDATE `username` = `username`;

CREATE TABLE IF NOT EXISTS `bookings` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `reference_no` VARCHAR(32) NOT NULL,
  `customer_name` VARCHAR(80) NOT NULL,
  `phone` VARCHAR(25) NOT NULL,
  `email` VARCHAR(120) NOT NULL,
  `service` VARCHAR(80) NOT NULL,
  `pickup_address` TEXT NOT NULL,
  `destination_address` TEXT NOT NULL,
  `pickup_date` DATE NOT NULL,
  `package_type` VARCHAR(100) NOT NULL,
  `notes` TEXT NULL,
  `status` ENUM('Pending', 'In transit', 'Delivered') NOT NULL DEFAULT 'Pending',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bookings_reference_no_unique` (`reference_no`),
  KEY `bookings_pickup_date_index` (`pickup_date`),
  KEY `bookings_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
