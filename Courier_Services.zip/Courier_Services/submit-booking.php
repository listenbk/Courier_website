<?php
require_once __DIR__ . '/includes/config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: booking.php'); exit; }

$fields = ['name', 'phone', 'email', 'service', 'pickup', 'destination', 'pickup_date', 'package'];
$data = [];
foreach ($fields as $field) { $data[$field] = trim((string)($_POST[$field] ?? '')); }
$data['notes'] = trim((string)($_POST['notes'] ?? ''));

if (in_array('', array_slice($data, 0, 8), true) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL) || strlen($data['name']) > 80 || strlen($data['notes']) > 500) {
    header('Location: booking.php?error=1'); exit;
}
$reference = 'MMC-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
try {
    $statement = db()->prepare('INSERT INTO bookings (reference_no, customer_name, phone, email, service, pickup_address, destination_address, pickup_date, package_type, notes) VALUES (:reference, :name, :phone, :email, :service, :pickup, :destination, :pickup_date, :package, :notes)');
    $statement->execute(['reference' => $reference, 'name' => $data['name'], 'phone' => $data['phone'], 'email' => $data['email'], 'service' => $data['service'], 'pickup' => $data['pickup'], 'destination' => $data['destination'], 'pickup_date' => $data['pickup_date'], 'package' => $data['package'], 'notes' => $data['notes']]);
} catch (PDOException $exception) {
    header('Location: booking.php?error=1'); exit;
}
header('Location: booking.php?success=1');
