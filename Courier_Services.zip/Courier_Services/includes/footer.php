</main>
<footer class="site-footer">
  <div class="container footer-grid">
    <div><a class="brand brand-light" href="index.php"><span class="brand-mark">MM</span><span>Mount Mary<small>COURIERS</small></span></a><p>Moving what matters, with care and clarity. Your trusted delivery partner from doorstep to destination.</p></div>
    <div><h3>Quick links</h3><a href="about.php">About us</a><a href="services.php">Our services</a><a href="why-us.php">Why choose us</a><a href="contact.php">Contact</a></div>
    <div><h3>Services</h3><a href="services.php#express">Express delivery</a><a href="services.php#business">Business logistics</a><a href="services.php#international">International shipping</a><a href="booking.php">Schedule a pickup</a></div>
    <div><h3>Get in touch</h3><p>Mount Mary Road, Bandra West<br>Mumbai, Maharashtra 400050</p><a href="tel:+919876543210">+91 98765 43210</a><a href="mailto:hello@mountmarycouriers.com">hello@mountmarycouriers.com</a></div>
  </div>
  <div class="container footer-bottom"><span>© <?= date('Y') ?> Mount Mary Couriers. All rights reserved.</span><a href="admin/login.php">Admin login</a></div>
</footer>
<script src="assets/js/site.js"></script>
</body>
</html>
