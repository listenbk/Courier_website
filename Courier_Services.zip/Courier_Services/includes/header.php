<?php
require_once __DIR__ . '/config.php';
$pageTitle = $pageTitle ?? SITE_NAME;
$activePage = $activePage ?? '';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Reliable local, national and international courier delivery from Mount Mary Couriers.">
  <title><?= e($pageTitle) ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Outfit:wght@500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="topbar"><div class="container topbar-inner"><span>Mon–Sat: 8:00 AM – 8:00 PM</span><a href="tel:+919876543210">+91 98765 43210</a><a href="mailto:hello@mountmarycouriers.com">hello@mountmarycouriers.com</a></div></div>
<header class="site-header">
  <div class="container nav-wrap">
    <a class="brand" href="index.php" aria-label="Mount Mary Couriers home"><span class="brand-mark">MM</span><span>Mount Mary<small>COURIERS</small></span></a>
    <button class="nav-toggle" aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button>
    <nav class="main-nav" aria-label="Main navigation">
      <a class="<?= $activePage === 'home' ? 'active' : '' ?>" href="index.php">Home</a>
      <a class="<?= $activePage === 'about' ? 'active' : '' ?>" href="about.php">About</a>
      <a class="<?= $activePage === 'services' ? 'active' : '' ?>" href="services.php">Services</a>
      <a class="<?= $activePage === 'why-us' ? 'active' : '' ?>" href="why-us.php">Why Us</a>
      <a class="<?= $activePage === 'contact' ? 'active' : '' ?>" href="contact.php">Contact</a>
      <a class="button button-small" href="booking.php">Book a Pickup <span>→</span></a>
    </nav>
  </div>
</header>
<main>
