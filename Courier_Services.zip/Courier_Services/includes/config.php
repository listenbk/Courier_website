<?php
declare(strict_types=1);

session_start();

const SITE_NAME = 'Mount Mary Couriers';
// Update these values to match your phpMyAdmin/MySQL setup.
const DB_HOST = 'localhost';
const DB_NAME = 'Enter_your_db_name';
const DB_USER = 'root';
const DB_PASSWORD = '';

// Keep disabled except while recovering an administrator account.
const ADMIN_RECOVERY_ENABLED = true;
const ADMIN_RECOVERY_KEY = 'MyPrivateResetKey2026';

function e(string $value): string { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
function base_url(string $path = ''): string { return $path; }

function db(): PDO {
    static $connection = null;
    if ($connection instanceof PDO) { return $connection; }
    $connection = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASSWORD,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
    return $connection;
}

function booking_status_class(string $status): string {
    return match ($status) {
        'Delivered' => 'status-delivered',
        'In transit' => 'status-transit',
        default => 'status-pending',
    };
}

?>
