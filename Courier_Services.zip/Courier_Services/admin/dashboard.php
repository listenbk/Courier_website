<?php
require_once __DIR__ . '/../includes/config.php';
if (!isset($_SESSION['admin'])) { header('Location: login.php'); exit; }
$bookings = [];
$databaseError = '';
try {
    $bookings = db()->query('SELECT reference_no, customer_name, phone, email, service, pickup_address, destination_address, pickup_date, package_type, status, created_at FROM bookings ORDER BY created_at DESC')->fetchAll();
} catch (PDOException $exception) {
    $databaseError = 'Database connection failed. Import mount_mary_couriers.sql and check includes/config.php.';
}
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Dashboard | Mount Mary Couriers</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Outfit:wght@500;600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/css/style.css"></head>
<body class="admin-body"><header class="admin-header"><div class="container"><strong>Mount Mary Couriers <span style="color:#93cfff">/ Admin</span></strong><div><a href="../index.php" style="font-size:.86rem;margin-right:17px">View site</a><a href="manage-admins.php" style="font-size:.86rem;margin-right:17px">Manage admins</a><a href="logout.php" class="button button-small" style="background:transparent;border-color:#7991a4">Sign out</a></div></div></header>
<main class="container admin-main"><h1>Pickup requests</h1><p><?= count($bookings) ?> request<?= count($bookings) === 1 ? '' : 's' ?> received.</p><?php if ($databaseError): ?><div class="notice error"><?= e($databaseError) ?></div><?php endif; ?><div class="admin-table-wrap"><?php if (!$bookings): ?><div class="empty-state"><h3>No pickup requests yet</h3><p>New customer requests will appear here.</p></div><?php else: ?><table class="admin-table"><thead><tr><th>Reference</th><th>Customer</th><th>Service</th><th>Collection</th><th>Destination</th><th>Pickup date</th><th>Status</th></tr></thead><tbody><?php foreach ($bookings as $booking): ?><tr><td><strong><?= e($booking['reference_no']) ?></strong><br><small><?= e($booking['created_at']) ?></small></td><td><?= e($booking['customer_name']) ?><br><small><?= e($booking['phone']) ?></small><br><small><?= e($booking['email']) ?></small></td><td><?= e($booking['service']) ?><br><small><?= e($booking['package_type']) ?></small></td><td><?= nl2br(e($booking['pickup_address'])) ?></td><td><?= nl2br(e($booking['destination_address'])) ?></td><td><?= e($booking['pickup_date']) ?></td><td><span class="status <?= booking_status_class($booking['status']) ?>"><?= e($booking['status']) ?></span></td></tr><?php endforeach; ?></tbody></table><?php endif; ?></div></main></body></html>
