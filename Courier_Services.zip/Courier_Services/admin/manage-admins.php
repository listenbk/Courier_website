<?php
require_once __DIR__ . '/../includes/config.php';
if (!isset($_SESSION['admin'])) { header('Location: login.php'); exit; }

$message = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $confirmation = (string)($_POST['password_confirmation'] ?? '');
    if (!preg_match('/^[a-zA-Z0-9._-]{3,80}$/', $username)) {
        $error = 'Username must use 3–80 letters, numbers, dots, underscores, or hyphens.';
    } elseif (strlen($password) < 10) {
        $error = 'Use a password with at least 10 characters.';
    } elseif ($password !== $confirmation) {
        $error = 'The password confirmation does not match.';
    } else {
        try {
            $statement = db()->prepare('INSERT INTO admins (username, password_hash) VALUES (:username, :password_hash)');
            $statement->execute(['username' => $username, 'password_hash' => password_hash($password, PASSWORD_DEFAULT)]);
            $message = 'New administrator created successfully.';
        } catch (PDOException $exception) {
            $error = $exception->getCode() === '23000' ? 'That username is already in use.' : 'Unable to create the administrator. Check the database connection.';
        }
    }
}
try { $admins = db()->query('SELECT id, username, created_at FROM admins ORDER BY created_at ASC')->fetchAll(); }
catch (PDOException $exception) { $admins = []; $error = 'Database connection failed. Check includes/config.php.'; }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Manage admins | Mount Mary Couriers</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Outfit:wght@500;600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/css/style.css"></head><body class="admin-body"><header class="admin-header"><div class="container"><strong>Mount Mary Couriers <span style="color:#93cfff">/ Admin</span></strong><div><a href="dashboard.php" style="font-size:.86rem;margin-right:17px">Pickup requests</a><a href="logout.php" class="button button-small" style="background:transparent;border-color:#7991a4">Sign out</a></div></div></header><main class="container admin-main"><h1>Manage administrators</h1><p>Create a separate, secure account for each person who needs access.</p><div class="booking-layout"><section class="form-card"><h2>Create an administrator</h2><p class="form-intro">Use a strong password of at least 10 characters.</p><?php if ($message): ?><div class="notice success"><?= e($message) ?></div><?php endif; ?><?php if ($error): ?><div class="notice error"><?= e($error) ?></div><?php endif; ?><form method="post"><div class="form-field"><label for="username">New username</label><input id="username" name="username" autocomplete="username" required maxlength="80" pattern="[A-Za-z0-9._-]{3,80}"></div><div class="form-field" style="margin-top:17px"><label for="password">New password</label><input id="password" name="password" type="password" autocomplete="new-password" required minlength="10"></div><div class="form-field" style="margin-top:17px"><label for="password-confirmation">Confirm password</label><input id="password-confirmation" name="password_confirmation" type="password" autocomplete="new-password" required minlength="10"></div><button class="button" type="submit">Create administrator →</button></form></section><aside class="aside-card"><h3>Existing administrators</h3><ul><?php foreach ($admins as $admin): ?><li><?= e($admin['username']) ?><br><small style="color:#bbcedd">Added <?= e($admin['created_at']) ?></small></li><?php endforeach; ?></ul><p>For safety, remove the default <code>admin</code> account from phpMyAdmin once your new account has been tested.</p></aside></div></main></body></html>
