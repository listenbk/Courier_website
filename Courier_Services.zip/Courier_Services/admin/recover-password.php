<?php
require_once __DIR__ . '/../includes/config.php';
if (!ADMIN_RECOVERY_ENABLED || ADMIN_RECOVERY_KEY === '') {
    http_response_code(403);
    exit('Administrator recovery is disabled. Enable it temporarily in includes/config.php.');
}

$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $key = (string)($_POST['recovery_key'] ?? '');
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $confirmation = (string)($_POST['password_confirmation'] ?? '');
    if (!hash_equals(ADMIN_RECOVERY_KEY, $key)) {
        $error = 'The recovery key is incorrect.';
    } elseif (!preg_match('/^[a-zA-Z0-9._-]{3,80}$/', $username)) {
        $error = 'Use a username with 3–80 letters, numbers, dots, underscores, or hyphens.';
    } elseif (strlen($password) < 10) {
        $error = 'Use a password with at least 10 characters.';
    } elseif ($password !== $confirmation) {
        $error = 'The password confirmation does not match.';
    } else {
        try {
            $statement = db()->prepare('INSERT INTO admins (username, password_hash) VALUES (:username, :password_hash) ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash)');
            $statement->execute(['username' => $username, 'password_hash' => password_hash($password, PASSWORD_DEFAULT)]);
            $success = 'Account saved. Disable recovery in config.php, then sign in using your new credentials.';
        } catch (PDOException $exception) {
            $error = 'The database could not be updated. Check your database settings.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Recover administrator | Mount Mary Couriers</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Outfit:wght@500;600;700;800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="../assets/css/style.css">
    </head>
    <body class="admin-body">
        <main class="admin-login">
            <a class="brand" href="../index.php">
                <span class="brand-mark">MM</span>
                <span>Mount Mary<small>COURIERS</small></span>
            </a>
            <section class="login-card">
                <h1>Recover admin access</h1>
                <p>Create or reset an administrator account. Disable this page immediately afterwards.</p>
                <?php if ($error): ?>
                    <div class="notice error"><?= e($error) ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="notice success"><?= e($success) ?></div>
                <?php endif; ?>
                <form method="post">
                    <div class="form-field">
                        <label for="recovery-key">Recovery key</label>
                        <input id="recovery-key" name="recovery_key" type="password" required>
                    </div>
                    <div class="form-field" style="margin-top:17px">
                        <label for="username">Username</label>
                        <input id="username" name="username" value="admin" required maxlength="80">
                    </div>
                    <div class="form-field" style="margin-top:17px">
                        <label for="password">New password</label>
                        <input id="password" name="password" type="password" autocomplete="new-password" required minlength="10">
                    </div>
                    <div class="form-field" style="margin-top:17px">
                        <label for="confirm-password">Confirm new password</label>
                        <input id="confirm-password" name="password_confirmation" type="password" autocomplete="new-password" required minlength("10"):
                    </div>
                    <button class("button") type("submit") style("width:100%;justify-content:center;margin-top:25px")>Save administrator →</button>
                </form>
            </section>
        </main>
    </body>
</html>
