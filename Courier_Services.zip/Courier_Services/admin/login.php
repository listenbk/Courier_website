<?php
require_once __DIR__ . '/../includes/config.php';
if (isset($_SESSION['admin'])) { header('Location: dashboard.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    try {
        $statement = db()->prepare('SELECT username, password_hash FROM admins WHERE username = :username LIMIT 1');
        $statement->execute(['username' => $username]);
        $admin = $statement->fetch();
        if ($admin && password_verify($password, $admin['password_hash'])) {
            session_regenerate_id(true); $_SESSION['admin'] = $admin['username']; header('Location: dashboard.php'); exit;
        }
        $error = 'Incorrect username or password.';
    } catch (PDOException $exception) {
        $error = 'Database connection failed. Import the SQL file and check includes/config.php.';
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Admin login | Mount Mary Couriers</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Outfit:wght@500;600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/css/style.css"></head><body class="admin-body"><main class="admin-login"><a class="brand" href="../index.php"><span class="brand-mark">MM</span><span>Mount Mary<small>COURIERS</small></span></a><section class="login-card"><h1>Welcome back</h1><p>Sign in to manage customer pickup requests.</p><?php if ($error): ?><div class="notice error"><?= e($error) ?></div><?php endif; ?><form method="post"><div class="form-field"><label for="username">Username</label><input id="username" name="username" autocomplete="username" required></div><div class="form-field" style="margin-top:17px"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required></div><button class="button" type="submit" style="width:100%;justify-content:center;margin-top:25px">Sign in →</button></form></section></main></body></html>
