document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      toggle.classList.toggle('open', isOpen);
      toggle.setAttribute('aria-expanded', String(isOpen));
    });
  }
  const trackForm = document.querySelector('[data-track-form]');
  if (trackForm) trackForm.addEventListener('submit', event => {
    event.preventDefault();
    const result = document.querySelector('[data-track-result]');
    const code = trackForm.querySelector('input').value.trim();
    result.textContent = code ? `Shipment ${code.toUpperCase()} is being prepared for dispatch. Our team will update you shortly.` : 'Please enter your tracking number.';
    result.classList.add('visible');
  });
});
