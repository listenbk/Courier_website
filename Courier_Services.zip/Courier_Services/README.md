# Mount Mary Couriers

A PHP courier-services website with a pickup form and MySQL-backed admin dashboard.

## Run locally

1. Import `mount_mary_couriers.sql` in phpMyAdmin.
2. Set your MySQL credentials in `includes/config.php`.
3. From this folder, run `php -S localhost:8000`, then open `http://localhost:8000`.

## Admin credentials

- Username: `admin`
- Password: `password`

Change the default admin password in the `admins` table before deploying. The PHP installation must have the PDO MySQL extension enabled.
